const domContainer = document.querySelector('#content');
const root = ReactDOM.createRoot(domContainer);
root.render(<h1>Hello CIFO 👋 </h1>);
